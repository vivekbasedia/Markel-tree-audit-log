
public class MerkleTree
{
 
  SHAHash hashobj;
  MerkleTree lefttree, righttree;
  int start, end, nextPower, size;
  
  static final boolean mode = false;
 
  public MerkleTree(MerkleTree old) 
  {
	  hashobj = new SHAHash(old.hashobj);
    lefttree = new MerkleTree(old.lefttree);
    righttree = new MerkleTree(old.righttree);
    start = old.start;
    end = old.end;
    nextPower = old.nextPower;
    size = old.size;
  }

  public MerkleTree(String s, int index) {
    lefttree = null;
    righttree = null;
    start = index;
    end = index;
    size = 1;
    nextPower = 1;
    hashobj = new SHAHash(s);
  }

  public MerkleTree(MerkleTree l, MerkleTree r) {
    if (l.end != r.start - 1) {
      System.out.println("Tree is not in sequence, lefttree end at " + l.end + "; righttree starts at " + r.start );
      System.exit(1);
    } else {
      lefttree = l;
      righttree = r;
      start = l.start;
      end = r.end;
      size = l.size + r.size;
      if(size < Math.max(l.nextPower, r.nextPower)) nextPower = Math.max(l.nextPower, r.nextPower);
      else nextPower = 2 * Math.max(l.nextPower, r.nextPower);
      hashobj = new SHAHash(l.hashobj, r.hashobj);
    }
  }

  public void display() {
    System.out.println("Size of tree: " + size);
    display_offset(0);
  }

  void display_offset(int offset) {
    for (int i = 0; i < offset; i ++) {
      System.out.print("  ");
    }
    System.out.println("["+ start + "," + end + "]: " + hashobj.toString());
    if (lefttree != null) lefttree.display_offset(offset+1);
    if (righttree != null) righttree.display_offset(offset+1);
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null)
      return false;
    if (!MerkleTree.class.isAssignableFrom(obj.getClass()))
      return false;
    final MerkleTree other = (MerkleTree) obj;

    if (start != other.start || end != other.end || nextPower != other.nextPower || size != other.size) {
      if (mode) System.out.println("Merkletree is different at node: "+ "["+ start + "," + end + "] :");
      return false;
    }
    if (!hashobj.equals(other.hashobj)) {
        if (mode) System.out.println("Merkletrees is different by hash at node: "+ "["+ start + "," + end + "]");
        return false;
    }
    if (lefttree == null || righttree == null) {
      assert(righttree == null && lefttree ==null);
      if (other.lefttree == null || other.righttree == null) {
        assert(other.righttree == null && other.lefttree == null);
        return true;
      }
      if (mode) System.out.println("Merkletrees is different at node: "+ "["+ start + "," + end + "] :");
      return false;
    }
    return (lefttree.equals(other.lefttree) && (righttree.equals(other.righttree)));
  }

}
