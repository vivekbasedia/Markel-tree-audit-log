import java.util.Queue;
import java.util.LinkedList;
import java.util.List;

public class Auditor {
  static final boolean mode = false;
  SHAHash rootHash;
  LogServer server;

  public Auditor(LogServer server) {
    rootHash = server.tree.hashobj;
    this.server = server;
  }

  public boolean isMember(String event, int index) {
    LinkedList<SHAHash> path = server.genPath(index);
    SHAHash hash = buildHash(event, index, server.tree.end, path);
    if (mode)  System.out.println(hash.toString());
    return hash.equals(rootHash);
  }

  public SHAHash buildHash(String event, int index, int end, LinkedList<SHAHash> path) {
    if (mode) System.out.println("End point " + end);
    if (end == 0 ) {
      if (path.size() != 0) {
        System.out.println("hash list is not empty!");
      }
      return new SHAHash(event);
    }
    int middle = greatestPowerTwoSmaller(end);

    if (index < middle) {
      SHAHash right = path.removeLast();
      SHAHash left = buildHash(event, index, middle - 1, path);
      if (mode)  System.out.println("Received hash" + left.toString());
      if (mode)  System.out.println("Merge with right:" + right.toString());
      return new SHAHash(left, right);
    }
    SHAHash left = path.removeLast();
    SHAHash right = buildHash(event, index - middle, end - middle, path);
    if (mode)  System.out.println("Received hash:" + right.toString());
    if (mode)  System.out.println("Merge with left:" + left.toString());
    return new SHAHash(left, right);
  }


    public boolean isConsistent(LogServer newLogServer) {
      if (server.tree.size > newLogServer.tree.size)
        return false;
      if (server.tree.size == newLogServer.tree.size) {
        if (rootHash.equals(newLogServer.currentRootHash())) {
          return true;
        }
        return false;
      }

      int index = server.tree.end;
      LinkedList<SHAHash> path = newLogServer.genProof(index);

      int end = newLogServer.tree.end;

      while (index % 2 != 0 ) {
        end /= 2;
        index /= 2;
      }
      
      SHAHash hash = path.removeFirst();
      hash = buildProofHash(hash, index, end, path);

      if (mode)  System.out.println(hash.toString());
      return hash.equals(rootHash);
    }

    public SHAHash buildProofHash(SHAHash hash, int index, int end, LinkedList<SHAHash> path) {
      if (mode) System.out.println("End point " + end);

      if (end == 0 ) {
        if (path.size() != 0) {
          System.out.println("hash list is not empty!");
        }
        return hash;
      }
      int middle = greatestPowerTwoSmaller(end);

      if (index < middle) {
        SHAHash removed = path.removeLast();
        if (mode)  System.out.println("Remove hash" + removed.toString());
        return buildProofHash(hash, index, middle - 1, path);
      }
      SHAHash left = path.removeLast();
      SHAHash right = buildProofHash(hash, index - middle, end - middle, path);
      if (mode)  System.out.println("Received hash" + right.toString());
      if (mode)  System.out.println("Merge with left" + left.toString());
      return new SHAHash(left, right);
    }

  public int greatestPowerTwoSmaller(int index) {
   
    return Integer.highestOneBit(index);
  }

}
