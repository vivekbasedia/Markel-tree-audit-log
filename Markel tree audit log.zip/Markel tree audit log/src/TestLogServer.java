import java.util.LinkedList;
import java.util.Scanner;
import java.util.Arrays;


public class TestLogServer {
  public static void main(String [] args) {
	  
	 //int testcase = 0;
	 
	 System.out.println("Enter test file number:(1 or 2 or 3 or 4 or 5 or 6) ");
	 Scanner scanner = new Scanner(System.in);
	 int testcasefile = scanner.nextInt();
	 System.out.println("test file selected  is " + testcasefile);
	 
	
      switch(testcasefile) {
         case 1 :
        	 LogServer l1 = new LogServer("C:/Users/vivek/ISEPPROJ/MerkleHastTree/src/WorkLoad/DS1-trace.txt");
        	    l1.tree.display();
        	    System.out.println("Audit path");
        	     for (SHAHash hashobj : l1.genPath(0)) {
        	       System.out.println(hashobj);
        	     }
        	     System.out.println("Proof");
        	     for (SHAHash hashobj : l1.genPath(0)) {
        	       System.out.println(hashobj);
        	     }
            break;
         case 2 :
        	 LogServer l2 = new LogServer("C:/Users/vivek/ISEPPROJ/MerkleHastTree/src/WorkLoad/DS2-trace.txt");
        	    l2.tree.display();
        	    System.out.println("Audit path");
        	     for (SHAHash hashobj : l2.genPath(1)) {
        	       System.out.println(hashobj);
        	     }
        	     System.out.println("Proof");
        	     for (SHAHash hashobj : l2.genPath(5)) {
        	       System.out.println(hashobj);
        	     }
         case 3:
        	 LogServer l3 = new LogServer("C:/Users/vivek/ISEPPROJ/MerkleHastTree/src/WorkLoad/DS3-trace.txt");
        	    l3.tree.display();
        	    System.out.println("Audit path");
        	     for (SHAHash hashobj : l3.genPath(1)) {
        	       System.out.println(hashobj);
        	     }
        	     System.out.println("Proof");
        	     for (SHAHash hashobj : l3.genPath(5)) {
        	       System.out.println(hashobj);
        	     }
            break;
         case 4:
        	 LogServer l4 = new LogServer("C:/Users/vivek/ISEPPROJ/MerkleHastTree/src/WorkLoad/DS4-trace.txt");
        	    l4.tree.display();
        	    System.out.println("Audit path");
        	     for (SHAHash hashobj : l4.genPath(0)) {
        	       System.out.println(hashobj);
        	     }
        	     System.out.println("Proof");
        	     for (SHAHash hashobj : l4.genPath(0)) {
        	       System.out.println(hashobj);
        	     }
        	     break;
         case 5 :
        	 LogServer l5 = new LogServer("C:/Users/vivek/ISEPPROJ/MerkleHastTree/src/WorkLoad/DS5-trace.txt");
        	    l5.tree.display();
        	    System.out.println("Audit path");
        	     for (SHAHash hashobj : l5.genPath(1)) {
        	       System.out.println(hashobj);
        	     }
        	     System.out.println("Proof");
        	     for (SHAHash hashobj : l5.genPath(5)) {
        	       System.out.println(hashobj);
        	     }
            break;
         case 6 :
        	 LogServer l6 = new LogServer("C:/Users/vivek/ISEPPROJ/MerkleHastTree/src/WorkLoad/DS6-trace.txt");
        	    l6.tree.display();
        	    System.out.println("Audit path");
        	     for (SHAHash hashobj : l6.genPath(1)) {
        	       System.out.println(hashobj);
        	     }
        	     System.out.println("Proof");
        	     for (SHAHash hashobj : l6.genPath(5)) {
        	       System.out.println(hashobj);
        	     }
             break;
         default :
            System.out.println("Invalid testcase");
      }
    
   
     
    


    
     }
  
  }
